import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		context.registerShutdownHook();
		System.out.println("first line");
		Employee obj = (Employee) context.getBean("emp");

		System.out.println(obj.getId());
		System.out.println(obj.getName());
		System.out.println(obj.getAddress().getCity());
	}
}
