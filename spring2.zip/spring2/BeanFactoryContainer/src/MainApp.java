import javax.annotation.Resource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

public class MainApp {

	public static void main(String[] args) {
		/*Resource resource=new FileSystemResource("Beans.xml");
		BeanFactory factory=new XmlBeanFactory(resource);*/
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("Beans.xml"));
	//ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
	System.out.println("first line");
	Employee obj=(Employee)factory.getBean("emp");

    System.out.println(obj.getId());
	System.out.println(obj.getName());
	
	Employee obj1=(Employee)factory.getBean("emp1");
	System.out.println(obj1.getName());
	
	Employee obj2=(Employee)factory.getBean("emp2");
	System.out.println(obj2.getName());
	
	Employee obj3=(Employee)factory.getBean("emp3");
	System.out.println(obj3.getName());
	}
}
